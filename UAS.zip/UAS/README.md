# Logistik laravel-CI Framework

Turn on server using command `php artisan serve` on logistik-restserver directory

