<!DOCTYPE html>
<html lang="en">
<head>
  <title>Logistic</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  body {
  background-image: url("123.png");
  background-repeat: no-repeat, repeat;
  background-color: #cccccc;
}
  </style>
</head>


<body>
<div class="fixed-center">
  <h2 align="center">Halo</h2>
</div>
<div class="center">
<h2 align="center">
  <a href="member" class="btn btn-primary">Data Client</a>
  </h2>
</div>

</body>
</html>